<?php
##
# © 2020 Partners HealthCare Technology & Innovation Department
##

namespace Partners\PHSDayOfWeek;

use ExternalModules\AbstractExternalModule;
use ExternalModules\ExternalModules;

class PHSDayOfWeek extends AbstractExternalModule
{
  private $tag = '@DAYOFWEEK';

  function redcap_survey_page_top( $project_id, $record, $instrument, $event_id ) {
    $this->getDayOfWeek($project_id, $record, $instrument, $event_id );
  }

  function redcap_data_entry_form_top( $project_id, $record, $instrument, $event_id ) {
    $this->getDayOfWeek($project_id, $record, $instrument, $event_id );
  }


  /**
   * @param $project_id
   * @param $record
   * @param $instrument
   * @param $event_id
   */
  function getDayOfWeek( $project_id, $record, $instrument, $event_id ) {
    global $Proj;

    $fields_on_this_form = ( isset($instrument) && strlen($instrument) > 0 ) ? array_keys($Proj->forms[$instrument]['fields']) : array_keys($Proj->metadata);
    $tags_found_on_page = array();
    foreach ( $fields_on_this_form as $field ) {
      if ( strpos($Proj->metadata[$field]['misc'],$this->tag) !== FALSE ) {
        $tags_found_on_page[] = $field; // add it to the array
      }
    }

    if ( empty($tags_found_on_page) || count($tags_found_on_page)<=0 ) {
      return; // no tags founds that match what we are looking for
    }

    $i=0;
    foreach ( $tags_found_on_page as $field ) {
      if ( $i==0 ) {
        print "<script type='text/javascript'>
                var daye = new Date();
                var weekdaye = new Array(7);
                weekdaye[0] = \"SUN\";
                weekdaye[1] = \"MON\";
                weekdaye[2] = \"TUE\";
                weekdaye[3] = \"WED\";
                weekdaye[4] = \"THU\";
                weekdaye[5] = \"FRI\";
                weekdaye[6] = \"SAT\";
        </script>";
      }
      $i++;
      print "<script type='text/javascript'>
              $(document).ready(function() {               
                if ($(\"[name = '$field']\").val().length <= 0 ) {
                  $(\"[name = '$field']\").val(weekdaye[daye.getDay()]);
                }        
              });
      </script>";
    }
  }
}
