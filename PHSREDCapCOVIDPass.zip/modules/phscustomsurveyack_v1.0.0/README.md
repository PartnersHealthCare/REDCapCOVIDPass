# PHS Custom Survey Acknowledgement screen
Hack-y way of showing/hiding DIVs the final survey acknowledgement page

*Developed in 9.1.22*

 
