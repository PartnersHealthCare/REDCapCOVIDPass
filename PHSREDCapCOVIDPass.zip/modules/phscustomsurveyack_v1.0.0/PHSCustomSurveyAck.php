<?php
##
# © 2020 Partners HealthCare Technology & Innovation Department
##
namespace Partners\PHSCustomSurveyAck;

include_once("Util.php");
include_once("PHSCommon.php");


use Survey;
use REDCap;

class PHSCustomSurveyAck extends \ExternalModules\AbstractExternalModule
{

  /**
   * @param $project_id
   * @param null $record
   * @param $instrument
   * @param $event_id
   * @param null $group_id
   * @param $survey_hash
   * @param null $response_id
   * @param int $repeat_instance
   */
  public function redcap_survey_complete ( $project_id, $record = NULL, $instrument, $event_id, $group_id = NULL, $survey_hash, $response_id = NULL, $repeat_instance = 1 ) {
    // We REALLY don't want to re-pull this data - creates additional traffic that is not necessary.
    // For now, this module is a HACK and requires very specific configuration

    print "<style type=\"text/css\"> 
                .divtbl {
                    display: table;
                }
                 #surveyacknowledgment div.divtbl {
                    display: table;
                    width: 95%;
                }
                .divtblrow {
                    display: table-row;
                    vertical-align: middle;
                }
                .divtblcellhdr {
                    display: table-cell;
                    vertical-align: middle;
                    text-align: left;
                    border-bottom: 1px solid #ccc !important
                }
                .divtblcelldata {
                    display: table-cell;
                    vertical-align: middle;
                    text-align: center;
                    overflow-wrap: break-word;
                    word-break: break-all;
                    padding-top: 10px;
                    padding-bottom: 10px;
                    border-bottom: 2px solid #ccc !important
                }
                #surveyacknowledgment div.divtblcelldata {
                    display: table-cell;
                    vertical-align: middle;
                    text-align: center;
                    overflow-wrap: break-word;
                    word-break: break-all;
                    padding-top: 15px !important;
                    padding-bottom: 15px !important;
                    border-bottom: 2px solid #ccc !important
                }
                
                
                
                #surveyacknowledgment p.nopadd {
                    padding: 0px 0 !important;
                }
                
                #surveyacknowledgment span.piping_receiver {
                    font-size: 28px !important;
                    line-height: 1em !important;
                }
                #surveyacknowledgment a.btn {
                    line-height: 32px !important;
                    text-align: center !important;
                    color: white;
                }
                
                .phsdowdivsec {
                    font-size: 60px !important;
                    line-height: 1em !important;
                    font-weight: bold;
                }
                .phsnamedivsec {
                    font-size: 40px !important;
                    line-height: 1em !important;
                    font-weight: bold;
                }
                
                .phsdatedivsec {
                    font-size: 20px !important;
                    line-height: 0em !important;
                }
                
                #largebtndiv a {
                    font-size: 30px !important;
                }
                .btn-xlarge {
                    padding: 28px 38px;
                    font-size: 28px; 
                    
                    -webkit-border-radius: 8px;
                       -moz-border-radius: 8px;
                            border-radius: 8px;
                }
            </style>";
    print "<script type=\"text/javascript\">";
    print " $(document).ready(function() { ";
    print "    $( \"button:contains('Close survey')\").closest('div').css('display','none');"; // hide the Close survey button
    print "    $( \".phsdowdiv\").find('span.piping_receiver').each ( function () {($(this).replaceWith((\"<section class='phsdowdivsec'>\" + this.innerHTML + \"</section>\")))});";
    print "    $( \".phsdatediv\").find('span.piping_receiver').each ( function () {($(this).replaceWith((\"<section class='phsdatedivsec'>\" + this.innerHTML + \"</section>\")))});";
    print "    $( \".phsnamediv\").find('span.piping_receiver').each ( function () {($(this).replaceWith((\"<section class='phsnamedivsec'>\" + this.innerHTML + \"</section>\")))});";
    print "    if ( $('#finres > .piping_receiver:contains(\"None of the above - I am not experiencing any symptoms\")').length > 0 || $('#finres > .piping_receiver:contains(\"No Symptoms - I am not experiencing any symptoms\")').length > 0 || $('#finres > .piping_receiver:contains(\"No Symptoms\")').length > 0) {
                  // NO Symptoms
                  $('#hassymptoms').css('display','none');
                  $('#hasnosymptoms').css('display','block');
                  $('#finres').css('display','none');
                }
                else {
                  // Has Symptoms
                  $('#hassymptoms').css('display','block');
                  $('#hasnosymptoms').css('display','none');
                  $('#finres').css('display','none');
                }
                
                // Final day of the week
                if ( $('#findayweek > .piping_receiver:contains(\"MON\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', '#337ab7');
                }
                if ( $('#findayweek > .piping_receiver:contains(\"TUE\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', 'Green');
                }
                if ( $('#findayweek > .piping_receiver:contains(\"WED\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', 'Gold');
                }
                if ( $('#findayweek > .piping_receiver:contains(\"THU\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', '#8B4513');
                }
                if ( $('#findayweek > .piping_receiver:contains(\"FRI\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', 'Pink');
                }
                if ( $('#findayweek > .piping_receiver:contains(\"SAT\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', 'Orange');
                }
                if ( $('#findayweek > .piping_receiver:contains(\"SUN\")').length > 0 ) {
                  $(\".bannerdiv\").css('background-color', 'Purple');
                }
                
                ";
    print "});";
    print "</script>";
  }

  // Log Wrapper
  // All credit here to Andy Martin!
  public static function log() {
      if (class_exists("Partners\PHSEmployeeSync\Util")) {
        call_user_func_array("Partners\PHSEmployeeSync\Util::log", func_get_args());
      }
  }
}