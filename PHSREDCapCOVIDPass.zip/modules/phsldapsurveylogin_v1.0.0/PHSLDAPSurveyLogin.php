<?php
##
# © 2020 Partners HealthCare Technology & Innovation Department
##

/**
 * PHSLDAPSurveyLogin
 */

namespace Partners\PHSLDAPSurveyLogin;

include_once("PHSCommon.php");

use Survey;
use REDCap;
use RCView;
use DateTime;

class PHSLDAPSurveyLogin extends \ExternalModules\AbstractExternalModule
{
    protected $max_login_fail = 5;

    function hook_survey_page_top($project_id, $record = NULL, $instrument, $event_id, $group_id = NULL, $survey_hash, $response_id = NULL, $repeat_instance = 1 ){
        global $auth_meth;
        // Check if the system is setup to use LDAP
        if ( !isset($auth_meth) ) return false; // let the survey keep going
        if ( $auth_meth != 'ldap_table' ) return false; // let the survey keep going

        // Skip if a record is already defined
        if (!empty($record)) return false;

        // IS THIS A PUBLIC SURVEY?
        global $Proj;
        $survey_id = @$Proj->forms[$instrument]['survey_id'];

        // Get the public hash for this arm
        $public_hash = Survey::getSurveyHash($survey_id, $event_id);

        // Skip if not the public survey
        if ($public_hash !== $survey_hash) {
            // This is not the public survey!
            return false;
        }

        // Is this the login post-back
        if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['redcap_login_a38us_09i85'])) {
          $login_fail = false;
          if ( isset ( $_POST['username']) ) {
            // Trim
            $_POST['username'] = trim($_POST['username']);
            // Make sure it's not longer than 255 characters to prevent attacks via hitting upper bounds
            if (strlen($_POST['username']) > 255) {
              $_POST['username'] = substr($_POST['username'], 0, 255);
            }

            $ldap_domain_override         = $this->getProjectSetting("phsloing-domain-override");
            if ( !empty($ldap_domain_override) && strlen(trim($ldap_domain_override))>0 ){ $ldap_domain_override = trim($ldap_domain_override); }
            else $ldap_domain_override = '';

            //$result = PHSCommon::auth_user_ldap_em ( $_POST['username'], $_POST['password'], $ldap_domain_override);
            $result = PHSCommon::auth_user_ldap_REDCAP ( $_POST['username'], $_POST['password'] );

            if ( $result ) {
                // log the user out
              PHSCommon::auth_user_ldap_REDCAP_LOGOUT();
              $login_fail = false;

              // We have to do some JS here to put the parameters where they need to be
              $first_name_var         = $this->getProjectSetting("phsloing-user-first-name");
              $last_name_var          = $this->getProjectSetting("phsloing-user-last-name");
              $user_name_var          = $this->getProjectSetting("phsloing-user-user-name");
              $user_email_var         = $this->getProjectSetting("phsloing-user-email");
              $user_display_name_var  = $this->getProjectSetting("phsloing-user-display-name");

              if ( $this->getProjectSetting("phsloing-create-custom-record-after-login") == 1 ) {
                //EXPERIMENTAL
                // insert a record in the project with the data based on the mapping
                $target_survey_id = $Proj->firstFormSurveyId;
                $target_survey_form = $Proj->surveys[$target_survey_id]['form_name'];
                // map the data and prep it for insert
                //$next_record_id = getAutoID($Proj->project_id); // AutoID is the problem we're trying to avoid!
                $look_exit_count = 10;
                $next_record_id = rand(1,99999)."_".rand(1,9)."_".rand(1,99999);
                $record_is_unique_in_project = true;
                for ( $z=0; $z<=$look_exit_count; $z++ ) {
                  if ( PHSCommon::check_if_record_id_exists( $next_record_id, $Proj->project_id, $Proj->table_pk ) == true ) {
                    $next_record_id = rand(1,99999)."_".rand(1,9)."_".rand(1,99999); // generate a new one and check again
                    $record_is_unique_in_project = false;
                  }
                  else {
                    $record_is_unique_in_project = true;
                  }

                  if ( $record_is_unique_in_project )
                    break;
                }

                if ( $record_is_unique_in_project == false) {
                  // this means that the record loop exit condition took place
                  // let the survey continue with a normal AutoID
                  return;
                }
                $data_to_import = array();

                // First Name
                if ( strlen(trim($this->getProjectSetting("phsloing-user-first-name")))>0 ) {
                  $data_to_import[$this->getProjectSetting("phsloing-user-first-name")] = $_SESSION['userfn'];
                }
                // Last Name
                if ( strlen(trim($this->getProjectSetting("phsloing-user-last-name")))>0 ) {
                  $data_to_import[$this->getProjectSetting("phsloing-user-last-name")] = $_SESSION['userln'];
                }
                // User Name
                if ( strlen(trim($this->getProjectSetting("phsloing-user-user-name")))>0 ) {
                  $data_to_import[$this->getProjectSetting("phsloing-user-user-name")] = $_SESSION['username'];
                }
                // Email - we actually don't have it
                if ( strlen(trim($this->getProjectSetting("phsloing-user-email")))>0 ) {
                  $data_to_import[$this->getProjectSetting("phsloing-user-email")] = $_SESSION['usermail'];
                }
                // Display Name - we actually don't have it
                if ( strlen(trim($this->getProjectSetting("phsloing-user-display-name")))>0 ) {
                  $data_to_import[$this->getProjectSetting("phsloing-user-display-name")] = $_SESSION['userdisplayname'];
                }

                $final_data = array();
                $final_data[$next_record_id] = array();
                $final_data[$next_record_id][$Proj->firstEventId] = $data_to_import;

                if ( $this->getProjectSetting("phsloing-create-custom-record-after-login-nosave") == 1 ) {
                  list ($participant_id, $survey_hash) = Survey::getFollowupSurveyParticipantIdHash($target_survey_id, $next_record_id, $Proj->firstEventId, false, null); // No instance for now
                  if ( $survey_hash == false || is_null($survey_hash)) {
                    // there was a problem creating the survey hash
                    // continue normally
                    // @todo maybe re-direct to SaveRecord part
                    return;
                  }
                  else {
                    $pipe_fields = "";
                    if ( strlen(trim($this->getProjectSetting("phsloing-user-first-name")))>0 ) {
                      $pipe_fields .= "&". urlencode($this->getProjectSetting("phsloing-user-first-name"))."=".urlencode($_SESSION['userfn']);
                    }
                    // Last Name
                    if ( strlen(trim($this->getProjectSetting("phsloing-user-last-name")))>0 ) {
                      $pipe_fields .= "&". urlencode($this->getProjectSetting("phsloing-user-last-name"))."=".urlencode($_SESSION['userln']);
                    }
                    // User Name
                    if ( strlen(trim($this->getProjectSetting("phsloing-user-user-name")))>0 ) {
                      $pipe_fields .= "&". urlencode($this->getProjectSetting("phsloing-user-user-name"))."=".urlencode($_SESSION['username']);
                    }
                    // Let's pipe everything, why not!! Not as secure as I want it, but should work for now
                    // Email - we actually don't have it
                    if ( strlen(trim($this->getProjectSetting("phsloing-user-email")))>0 ) {
                      $pipe_fields .= "&".urlencode($this->getProjectSetting("phsloing-user-email"))."=". urlencode($_SESSION['usermail']);
                    }
                    // Display Name - we actually don't have it
                    if ( strlen(trim($this->getProjectSetting("phsloing-user-display-name")))>0 ) {
                      $pipe_fields .= "&".urlencode($this->getProjectSetting("phsloing-user-display-name"))."=".urlencode($_SESSION['userdisplayname']);
                    }

                    // REDIRECT TO THE NEW SURVEY HASH
                    print "<script type=\"text/javascript\"> $(document).ready(function() { ";
                    print "     $(location).attr('href',\"".APP_PATH_SURVEY_FULL . "?s=" . $survey_hash.$pipe_fields."\");";
                    print "});".
                      "</script>";
                    // stop the rest of the page from loading
                    \ExternalModules\ExternalModules::exitAfterHook();
                  }
                }
                else {
                    $pd = REDCap::saveData($Proj->project_id, 'array', $final_data);
                    if ( $pd ) {
                      $new_id = array_shift($pd['ids']);
                      if ($new_id == $next_record_id ) {
                        // Get the survey hash for the new record
                        // no surveys are complete at the moment since this is a brand-new record. So we don't care about the status
                        list ($participant_id, $survey_hash) = Survey::getFollowupSurveyParticipantIdHash($target_survey_id, $next_record_id, $Proj->firstEventId, false, null); // No instance for now
                        // REDIRECT TO THE NEW SURVEY HASH
                        print "<script type=\"text/javascript\"> $(document).ready(function() { ";
                        print "     $(location).attr('href',\"".APP_PATH_SURVEY_FULL . "?s=" . $survey_hash."\");";
                        print "});".
                          "</script>";
                        // Stop the rest of the page from loading
                        \ExternalModules\ExternalModules::exitAfterHook();
                      }
                      else {
                        // something is wrong with this - just send them to the public survey URL
                        // Let survey proceed
                        return true;
                      }
                    }
                }
              }
              else {
                print "<script type=\"text/javascript\"> $(document).ready(function() { ";
                // First Name
                if ( !empty($first_name_var) && strlen(trim($first_name_var))>0 ) {
                  print "$(\"[name = '".htmlentities($first_name_var)."']\").val(\"".htmlentities($_SESSION['userfn'])."\");";
                  print "setTimeout(function(){ $(\"[name = '".htmlentities($first_name_var)."']\").select(); },100);";
                  print "setTimeout(function(){ $(\"[name = '".htmlentities($first_name_var)."']\").blur(); },101);";
                  print "setTimeout(function(){ $(\"[name = '".htmlentities($first_name_var)."']\").blur(); },102);";
                }
                // Last Name
                if ( !empty($last_name_var) && strlen(trim($last_name_var))>0 ) {
                  print "$(\"[name = '".htmlentities($last_name_var)."']\").val(\"".htmlentities($_SESSION['userln'])."\");";
                  print "setTimeout(function(){ $(\"[name = '".htmlentities($last_name_var)."']\").select(); },103);";
                  print "setTimeout(function(){ $(\"[name = '".htmlentities($last_name_var)."']\").blur(); },104);";
                  print "setTimeout(function(){ $(\"[name = '".htmlentities($last_name_var)."']\").blur(); },105);";
                }
                // Display Name
                if ( !empty($user_display_name_var) && strlen(trim($user_display_name_var))>0 ) {
                  print "$(\"[name = '".htmlentities($user_display_name_var)."']\").val(\"".htmlentities($_SESSION['userdisplayname'])."\");";
                }
                // User Name
                if ( !empty($user_name_var) && strlen(trim($user_name_var))>0 ) {
                  print "$(\"[name = '".htmlentities($user_name_var)."']\").val(\"".htmlentities($_SESSION['username'])."\");";
                }
                // Email Name
                if ( !empty($user_email_var) && strlen(trim($user_email_var))>0 ) {
                  print "$(\"[name = '".htmlentities($user_email_var)."']\").val(\"".htmlentities($_SESSION['usermail'])."\");";
                }
                print "});".
                  "</script>";

                // Let survey proceed
                return true;
              }

              // Let survey proceed
              return true;
            }
            else {
                isset($_SESSION['lgn_a38us_09i85_fail_count']) && is_numeric($_SESSION['lgn_a38us_09i85_fail_count']) ?
                  $_SESSION['lgn_a38us_09i85_fail_count']++ : $_SESSION['lgn_a38us_09i85_fail_count'] = 1;
                if ( $_SESSION['lgn_a38us_09i85_fail_count'] > $this->max_login_fail ){
                    unset($_SESSION['lgn_a38us_09i85_fail_count']);
                  echo "<div class='invalid-response alert alert-danger text-center'>We could not use your login credentials to determine your identity - please provide the needed information manually.</div>";
                  return true; // let the survey proceed
                }

              $login_fail = true;
              $login_error_message = $this->getProjectSetting("phsloing-error-message");
              if (empty($login_error_message)) $login_error_message = "There was an error authenticating OR you the login credentials were invalid. Please try again!";
              echo "<div class='invalid-response alert alert-danger text-center'>$login_error_message</div>";
            }
          }
        }

        // This is a page reload - log the user out
          unset($_SESSION['username']);
          unset($_SESSION['userdisplayname']);
          unset($_SESSION['userfn']);
          unset($_SESSION['userln']);
          unset($_SESSION['usermail']);
          unset($_SESSION['logged_in_gFALw5bz']);
          unset($_SESSION['invalid_after_gFALw5bz']);
          if ( $_SESSION['lgn_a38us_09i85_fail_count'] > $this->max_login_fail )
              unset($_SESSION['lgn_a38us_09i85_fail_count']);

        // Render login form
        $phslogin_message = $this->getProjectSetting("phsloing-user-message");

        global $headerlogo, $institution; // logo from the control center
        ?>
            <form id="frm" method="POST">
                <div style='margin-top:20px; margin-bottom:20px;text-align:center;'>
                  <?php
                      if (trim($headerlogo) != "") {
                        echo "<img src='" . RCView::escape($headerlogo) . "' title='" . RCView::escape(strip_tags($institution)) . "' alt='" . RCView::escape(strip_tags($institution)) . "' style='margin:-5px 0 5px 20px;max-width:700px; expression(this.width > 700 ? 700 : true);'>";
                      }
                  ?>
                </div>
                <p class="instructions text-center"><?php echo $phslogin_message; ?></p>

                    <br>
                    <div class='input-group-phs'>
                        <span class='username' id='basic-addon1' style='width:100px;'>Username</span>
                        <input type='text' class='input_up_input' style='width:100%; height: 34px !important;' aria-describedby='basic-addon1' name='username' id='username' value='' tabindex='1' autocomplete='off'>
                    </div>
                    <div class='input-group-phs' style='margin-top:10px;'>
                        <span class='username' id='basic-addon1' style='width:100px;'>Password</span>
                        <input type='password' class='input_up_input' style='width:100%;' aria-describedby='basic-addon1' name='password' id='password' value='' tabindex='2' autocomplete='off'>
                    </div>
                    <input type='hidden' name='submitted' value='1'>
                    <input type='hidden' id='redcap_login_a38us_09i85' name='redcap_login_a38us_09i85' value=''>
                    <input type='hidden' id='__prefill' name='__prefill' value=''>
                <div class="text-center">
                    </p>
                    <button class="btn btn-primary" style="background-color: #008ab0; color: white !important;" type="submit" onclick="this.form.submit(); this.disabled=true;">Login</button>
                    </br>
                </div>
            </form>

            <script type="text/javascript">
              $(document).ready(function() {
                $('#container').fadeIn();
              });
            </script>

            <style>
                .username {
                    padding: 6px 12px;
                    font-size: 16px;
                    font-weight: bold;
                    line-height: 1;
                    color: white;
                    text-align: center;
                    background-color: #008ab0;
                    border: 1px solid #ccc;
                    vertical-align: middle;
                    border-right-color: rgb(204, 204, 204);
                    border-right-style: solid;
                    border-right-width: 1px;
                    border-right: 0;
                    display: table-cell;
                }

                .input_up_input {
                    height: 34px !important;
                    padding: 6px 12px;
                    font-size: 14px;
                    line-height: 1.42857143;
                    color: #555;
                    background-color: #efefef;
                    background-image: none;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                    border-top-left-radius: 4px;
                    border-bottom-left-radius: 4px;
                }

                .input-group-phs {
                    margin: auto;
                    width: 50%;
                    display: table;
                }
                .instructions {
                    font-weight: bold;
                }

                .invalid-response {
                    font-size: 16pt;
                    font-weight: bold;
                }
                #container {
                    display:none;
                    margin: 50px 0;
                    border-radius: 15px;
                }


            </style>
        <?php

        // stop the rest of the page from loading
        \ExternalModules\ExternalModules::exitAfterHook();
    }
}