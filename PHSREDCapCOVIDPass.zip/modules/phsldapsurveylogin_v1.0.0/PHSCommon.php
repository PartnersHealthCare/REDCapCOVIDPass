<?php
##
# © 2020 Partners HealthCare Technology & Innovation Department
##

namespace Partners\PHSLDAPSurveyLogin;

use Survey;
use REDCap;
use AUthentication;

class PHSCommon {
  /**
   *
   * @param $record_id
   * @param $project_id
   *
   * @return bool - TRUE - exists, false = it does NOT
   */
  public function check_if_record_id_exists ( $record_id, $project_id, $table_pk ) {
    try {
      define("NOAUTH", TRUE);
      $all_data = REDCap::getData(
        $project_id,
        'array',
        array($record_id),
        array($table_pk)
      );
      define("NOAUTH", FALSE);

      if ( count($all_data) == 0 ) return false; // ID is not in the project
      return true; // ID is in the project
    }
    catch ( Exception $ee ) {
      define("NOAUTH", FALSE);
      return false; // no idea
    }
  }

  /**
   *
   */
  public function get_unique_id_for_project ( $Proj ) {
    try {
      $look_exit_count = 10;
      $next_record_id = rand(1,99999)."_".rand(1,9)."_".rand(1,99999);
      $record_is_unique_in_project = true;
      for ( $z=0; $z<=$look_exit_count; $z++ ) {
        if ( self::check_if_record_id_exists( $next_record_id, $Proj->project_id, $Proj->table_pk ) == true ) {
          $next_record_id = rand(1,99999)."_".rand(1,9)."_".rand(1,99999); // generate a new one and check again
          $record_is_unique_in_project = false;
        }
        else {
          // Record is unique in the project
          return $next_record_id; // Return the ID
        }
      }

      if ( $record_is_unique_in_project == false) {
        // this means that the record loop exit condition took place
        // let the survey continue
        return false;
      }
      return $next_record_id; // should not get here
    }
    catch ( Exception $ee ) {
      return false;
    }
  }


  public function dummyloginfunction () {
    return;
  }

  /**
   * Use PEAR Auth
   */
  public function auth_user_ldap_REDCAP ( $username, $pwd ) {
    try {
      require_once APP_PATH_WEBTOOLS.'ldap/ldap_config.php';

      if ( !class_exists('Auth')) {
        require_once APP_PATH_LIBRARIES. 'PEAR/Auth.php';
      }

      // Set user/pass as Post values so they get processed correctly
      $_POST['password'] = $pwd;
      $_POST['username'] = $username;

      $dsn = Authentication::buildDsnArray();

      // Default
      $GLOBALS['authFail'] = 0;

      //if ldap and table authentication Loop through the available servers & authentication methods
      foreach ($dsn as $key=>$dsnvalue) {
        if (isset($a)) {
          unset($a);
        }
        $GLOBALS['authFail'] = 1;
        if ( strtolower($dsnvalue['type']) != 'ldap' ) continue;

        if ( !isset ($dsnvalue['dsnstuff']['attributes']) ) {
          $dsnvalue['dsnstuff']['attributes'] = array(
            'name','uid','cn','displayName','mail','sn','givenname'
          );
        }
        else {
          $dsnvalue['dsnstuff']['attributes'] = array_values (
            array_unique (
              array_merge (
                $dsnvalue['dsnstuff']['attributes'],
                array('name','uid','cn','displayName','mail','sn','givenname')
              )
            )
          );
        }

        $a = new \Auth( $dsnvalue['type'], $dsnvalue['dsnstuff'], "dummyloginfunction", false );

        // Expiration settings
        $oneDay = 3; // in seconds - we really don't want them to remain logged in

        $a->setExpire($oneDay);
        $a->start();

        if ($a->getAuth()) {
          // OK - we're authenticated - get the necessary data and then log out

          if ( strtolower($a->getUsername()) == strtolower($username) ) {
            // Map LDAP attributes to what we want them to be called in code
            $datamap = array(
              'displayname'   => 'userdisplayname',
              'mail'          => 'usermail',
              'sn'            => 'userln',
              'givenname'     => 'userfn'
            );
            $access = 1;
            $_SESSION['username'] = $a->getUsername();
            $_SESSION['logged_in_gFALw5bz'] = $access;
            $_SESSION['invalid_after_gFALw5bz'] = time() + 3600; // expire in 1 hour

            foreach ( $a->getAuthData() as $k => $v ) {
              // establish session variables
              if ( isset ($datamap[strtolower($k)]) )
                $_SESSION[$datamap[strtolower($k)]] = $v;
            }
            return true;
          }
          return false; // the username did not match
        }
      }
      return false;
    }
    catch ( Exception $ee ) {
      return false;
    } 
  }

  /**
   * We really don't want to stay logged in past the initial login
   */
  public function auth_user_ldap_REDCAP_LOGOUT() {
    try {
      require_once APP_PATH_WEBTOOLS.'ldap/ldap_config.php';

      if ( !class_exists('Auth')) {
        require_once APP_PATH_LIBRARIES. 'PEAR/Auth.php';
      }

      $dsn = Authentication::buildDsnArray();

      // Default
      $GLOBALS['authFail'] = 0;

      //if ldap and table authentication Loop through the available servers & authentication methods
      foreach ($dsn as $key=>$dsnvalue) {
        if (isset($a)) {
          unset($a);
        }
        $GLOBALS['authFail'] = 1;
        if (strtolower($dsnvalue['type']) != 'ldap') {
          continue;
        }

        $a = new \Auth($dsnvalue['type'], $dsnvalue['dsnstuff'], "dummyloginfunction", FALSE);
        $a->start();
        if ($a->checkAuth()) {
          $a->logout();
          $a->start();
        }
      }
    }
    catch ( Exception $ee ) {

    }
  }

  /**
   * Authenticate against LDAP
   * @param $username
   * @param $pwd
   * @param $usr_dom_override
   *
   * @return bool
   */
  public function auth_user_ldap_em ( $username, $pwd, $usr_dom_override ) {
    try {
      require_once APP_PATH_WEBTOOLS.'ldap/ldap_config.php';

      if(empty($username) || empty($pwd)) return false;

      $username = htmlentities($username); // escape the input

      // active directory server
      $ldap_host = strpos($GLOBALS['ldapdsn']['host'],'ldaps://') === false ? "ldaps://".trim($GLOBALS['ldapdsn']['host']) : trim($GLOBALS['ldapdsn']['host']);

      // active directory DN (base location of ldap search)
      $ldap_dn = $GLOBALS['ldapdsn']['basedn'];

      // domain, for purposes of constructing $user
      $ldap_usr_dom = '';
      if ( isset($usr_dom_override) && strlen($usr_dom_override)>1 ) {
        $ldap_usr_dom = $usr_dom_override;
      }
      else {
        $dnarr = ldap_explode_dn ( $ldap_dn,0);
        foreach ( $dnarr as $k => $v ) {
          if ( $k=='count' ) continue;
          $curr_dn = explode('=',$v);
          if ( $curr_dn ) {
            if ( count($curr_dn)!= 2 ) continue; // this should just be array(0=>'dc',1=>'domain')
            if ( strtolower($curr_dn[0]) != 'dc' ) continue; // we only want DC
            $ldap_usr_dom .= ".".$curr_dn[1];
          }
        }
        unset ($dnarr);
        if ( strlen($ldap_usr_dom)>0 )
          $ldap_usr_dom = "@".substr($ldap_usr_dom,1);
      }

      // connect to active directory
      try {
        $ldap = ldap_connect($ldap_host);
      }
      catch (Exception $ee ) {
        return false;
      }

      // configure ldap params
      ldap_set_option($ldap,LDAP_OPT_PROTOCOL_VERSION,$GLOBALS['ldapdsn']['version']);
      ldap_set_option($ldap,LDAP_OPT_REFERRALS,1);

      // verify user and password
      if($bind = @ldap_bind($ldap, $username.$ldap_usr_dom, $pwd)) {

        // valid
        // check presence in groups
        $filter = "(".$GLOBALS['ldapdsn']['userattr']."=".$username.")";
        $attr = $GLOBALS['ldapdsn']['attributes'];
        $result = ldap_search($ldap, $ldap_dn, $filter, array('name','uid','cn','displayName','mail','sn','givenname')) or exit("Unable to search LDAP server");
        $entries = ldap_get_entries($ldap, $result);
        ldap_unbind($ldap);
        unset($pwd); // cleanup
        //file_put_contents("/var/www/html/redcap/temp/blah.txt",var_export($entries,true));
        // Do some processing here
        $access = 0;
        $displayname = "";
        $mail = "";
        $first_name = "";
        $last_name = "";
        if ( is_array($entries) && count($entries)>0 ) {
          // We have an entry
          if ( $entries['count'] > 1 ) return false; // more than one account found!
          if ( $entries['count'] = 1 ) {
            //file_put_contents('/var/www/html/redcap/tauth.txt',var_export($entries,true),FILE_APPEND);

            // make sure that names match-up
            if ( strtolower($entries[0]['cn'][0]) == strtolower($username) ) {
              $access = 1;
              // Get the display name as well
              $displayname = $entries[0]['displayname'][0];
              $mail = $entries[0]['mail'][0];
              $first_name = $entries[0]['givenname'][0];
              $last_name = $entries[0]['sn'][0];
            }
          }
        }

        if($access != 0) {
          // establish session variables
          $_SESSION['username'] = $username;
          $_SESSION['userdisplayname'] = $displayname;
          $_SESSION['userfn'] = $first_name;
          $_SESSION['userln'] = $last_name;
          $_SESSION['usermail'] = $mail;
          $_SESSION['logged_in_gFALw5bz'] = $access;
          $_SESSION['invalid_after_gFALw5bz'] = time() + 3600; // expire in 1 hour
          return true;
        } else {
          // user has no rights
          return false;
        }

      } else {
        // invalid name or password
        return false;
      }
    }
    catch ( Exception $e ) {
      return false;
    }
  }
}