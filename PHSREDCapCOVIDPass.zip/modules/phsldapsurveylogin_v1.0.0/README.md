# PHSLDAPSurveyLogin

This external module, if enabled, will force LDAP Login credentails screen to be shown on surveys
 ONYL works if LDAP is enabled in REDCap!
 The following attributes will be retrieved from LDAP:
 'name','uid','cn','displayName','mail','sn','givenname'

*Developed in 9.1.22*

 
